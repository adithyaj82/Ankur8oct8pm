//
//  SlideViewController.swift
//  SideMenuTutorial
//
//  Created by adithya on 9/7/18.
//  Copyright © 2018 Kyle Suchar. All rights reserved.
//

import UIKit

class SlideViewController: UITableViewController {
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func share(_ sender: Any) {
        
        let activityVC = UIActivityViewController(activityItems: ["https://play.google.com/store/apps/details?id=com.nirvanza.pediatrichospital"], applicationActivities: nil)
        activityVC.popoverPresentationController?.sourceView = self.view
        self.present(activityVC, animated: true, completion: nil)
        
    }
    
}
