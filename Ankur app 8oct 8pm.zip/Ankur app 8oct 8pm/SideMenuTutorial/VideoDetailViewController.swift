//
//  VideoDetailViewController.swift
//  Ankur app
//
//  Created by adithya on 9/9/18.
//  Copyright © 2018 Kyle Suchar. All rights reserved.
//

import UIKit

class VideoDetailViewController: UIViewController {
    var vv = String()

    @IBOutlet weak var myWebView: UIWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
     //   let url = URL(string: vv)
      //  myWebView.loadRequest(URLRequest(url: url!))
        customizeNavBar()
        // Do any additional setup after loading the view.
        
        
        
    }
    override func viewWillAppear(_ animated: Bool) {
        let url = URL(string: vv)
        myWebView.loadRequest(URLRequest(url: url!))
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    override var preferredStatusBarStyle: UIStatusBarStyle{
        return UIStatusBarStyle.lightContent
    }
    func customizeNavBar() {
        
        navigationController?.navigationBar.tintColor = UIColor(displayP3Red: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        navigationController?.navigationBar.barTintColor = UIColor(displayP3Red: 47/255, green: 181/255, blue: 175/255, alpha: 1)
        
        
        //        navigationController?.navigationBar.tintColor = UIColor(colorLiteralRed: 255/255, green: 255/255, blue: 255/255, alpha: 1)
        //        navigationController?.navigationBar.barTintColor = UIColor(colorLiteralRed: 47/255, green: 181/255, blue: 175/255, alpha: 1)
        
        
        navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.white]
        
        
    }
    
    
}
